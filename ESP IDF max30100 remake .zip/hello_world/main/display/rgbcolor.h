#ifndef MAIN_DISPLAY_RGB_COLOR_H_
#define MAIN_DISPLAY_RGB_COLOR_H_


typedef struct
{
	uint8_t r;
	uint8_t g;
	uint8_t b;
} tRGBcolor;


#endif /* MAIN_DISPLAY_RGB_COLOR_H_ */
